package com.example.icia24hours

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_total_sales_amount.*

class TotalSalesAmount : AppCompatActivity() {

    lateinit var myHelperSBD: MainActivity.MyDBHelperSaleBreakDown
    lateinit var sqlDBSBD: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_total_sales_amount)
        title = "매출액"

        var totalSA:Int = 0

        myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
        sqlDBSBD = myHelperSBD.readableDatabase

        val c:Cursor = sqlDBSBD.rawQuery("select * from SaleBreakDownTBL", null)
        while(c.moveToNext()){
            totalSA += (c.getString(3).toInt())*(c.getString(5).toInt())
        }

        totalSalesAmount.setText(totalSA.toString())


    }
}
