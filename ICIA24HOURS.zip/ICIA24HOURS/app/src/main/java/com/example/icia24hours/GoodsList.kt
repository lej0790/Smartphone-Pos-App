package com.example.icia24hours

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_goods_list.*
import kotlinx.android.synthetic.main.listview_item.view.*
import kotlinx.android.synthetic.main.listviewitemgoodslist.view.*
import org.jetbrains.anko.toast

class GoodsList : AppCompatActivity() {

    lateinit var myHelperList:MainActivity.MyDBHelper
    lateinit var sqlDBList:SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_list)
        title = "상품목록"

        var listview: ListView
        var adapter:ListViewAdapter2
        adapter = ListViewAdapter2()

        listview = findViewById(R.id.lvForGoodsList)
        listview.adapter = adapter

        myHelperList = MainActivity.MyDBHelper(this, "GoodsDB",null,1)
        sqlDBList = myHelperList.readableDatabase

        val c2:Cursor
        c2 = sqlDBList.rawQuery("select * from GoodsTBL", null) // ;써야하나?

        while(c2.moveToNext()){

            adapter.addItem(c2.getString(1),c2.getString(4),
                c2.getString(2),c2.getString(5))

        }
        c2.close()
//        strSaveDiary1 = c1.getString(1)
//        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_account_box_black_36dp), "Box", "Account Box Black 36dp") ;

        listview.onItemClickListener = AdapterView.OnItemClickListener { _, view, position, id ->

            if(view.barCodeTV.text.toString() != ""){
                var intentForGDI = Intent(this,GoodsDetailInfo::class.java)
                intentForGDI.putExtra("barCode", view.barCodeTV.text.toString())
                startActivity(intentForGDI)
            }

        }

    }
}
