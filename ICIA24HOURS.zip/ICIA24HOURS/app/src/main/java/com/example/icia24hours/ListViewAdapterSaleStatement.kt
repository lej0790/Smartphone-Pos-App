package com.example.icia24hours

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ListViewAdapterSaleStatement: BaseAdapter() {

    private val listViewItemList:ArrayList<ListViewItemSaleStatement> = ArrayList<ListViewItemSaleStatement>()

    override fun getCount(): Int {
        return listViewItemList.size
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val pos:Int = position
        val context:Context = parent!!.getContext()
        var convertView:View? = convertView

        if(convertView == null){
            val inflater:LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.listview_item_salesstatement, parent, false)

        }
        val goodsNameTextView:TextView = convertView!!.findViewById(R.id.goodsNameSS) as TextView
        val barCodeTextView:TextView = convertView.findViewById(R.id.barCodeSS) as TextView
        val amountTextView:TextView = convertView.findViewById(R.id.amountSS) as TextView
        val salePriceTextView:TextView = convertView.findViewById(R.id.salePriceSS) as TextView

        val listViewItem:ListViewItemSaleStatement = listViewItemList.get(position)

        goodsNameTextView.setText(listViewItem.getGoodsName())
        barCodeTextView.setText(listViewItem.getBarCode())
        amountTextView.setText(listViewItem.getAmount())
        salePriceTextView.setText(listViewItem.getSalePrice())

        return convertView
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return listViewItemList.get(position)
    }

    fun addItem(goodsName:String, barCode:String, amount:String,salePrice:String){
        val item:ListViewItemSaleStatement = ListViewItemSaleStatement()

        item.setGoodsName(goodsName)
        item.setBarCode(barCode)
        item.setAmount(amount)
        item.setSalePrice(salePrice)

        listViewItemList.add(item)
    }




}