package com.example.icia24hours

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_goods_revise_r.*
import org.jetbrains.anko.toast

class GoodsReviseR : AppCompatActivity() {
    lateinit var myHelper: MainActivity.MyDBHelper
    lateinit var sqlDB: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_revise_r)
        title ="상품수정"

        myHelper = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)
        sqlDB = myHelper.readableDatabase
        var checkGoodsFlag:Boolean = true

        var goodsBarCode = intent.getStringExtra("barCode")

        val c4: Cursor
        c4 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

        while (c4.moveToNext()) {

            if (c4.getString(4) == goodsBarCode) {
                goodsNameR.setText(c4.getString(1))
                categoryR.setText(c4.getString(0))
                salePriceR.setText(c4.getString(2))
                unitPriceR.setText(c4.getString(3))
                barCodeR.setText(c4.getString(4))
                stockR.setText(c4.getString(5))
            }

        }
        c4.close()

        goodsReviseBtn.setOnClickListener {
            if((goodsNameR.text.toString() == "") || (categoryR.text.toString() == "") ||
                (salePriceR.text.toString() == "") || (unitPriceR.text.toString() == "") ||
                (barCodeR.text.toString() == "") || (stockR.text.toString() == "")){

                toast("입력하지 않은 상품정보가 있습니다.")

            }else{

                sqlDB = myHelper.readableDatabase
                val c1: Cursor
                c1 = sqlDB.rawQuery("select * from GoodsTBL", null)

                while(c1.moveToNext()){
                    val existingBarCode:String = c1.getString(4)
                    val insertBarCode:String = barCodeR.text.toString()
                    if(insertBarCode == existingBarCode){
                        sqlDB = myHelper.writableDatabase
                        sqlDB.execSQL("update GoodsTBL set category='"+categoryR.text.toString() + "', goodsName='"+
                                goodsNameR.text.toString()+"', salePrice='"+salePriceR.text.toString()+"', unitPrice='"+
                                unitPriceR.text.toString()+"', stock='"+stockR.text.toString()+
                                "' where barCode ='"+barCodeR.text.toString()+"'")

                        toast("상품이 수정되었습니다")
                        checkGoodsFlag = false

                        break
                    }
                }
                c1.close()

                if(checkGoodsFlag) {
                    toast("등록되어 있지 않은 상품이라 수정할 수 없습니다.")
                }

                checkGoodsFlag = true

            }
        }
    }

}

