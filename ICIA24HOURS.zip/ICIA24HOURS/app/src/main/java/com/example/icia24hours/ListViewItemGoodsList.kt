package com.example.icia24hours

class ListViewItemGoodsList {
    private lateinit var goodsName:String
    private lateinit var barCode:String
    private lateinit var salePrice:String
    private lateinit var stock:String

    fun setGoodsName(goodsName:String){
        this.goodsName=goodsName
    }
    fun setBarCode(barCode:String){
        this.barCode=barCode
    }
    fun setSalePrice(salePrice:String){
        this.salePrice=salePrice
    }
    fun setStock(stock:String){
        this.stock=stock
    }

    fun getGoodsName():String{
        return this.goodsName
    }
    fun getBarCode():String{
        return this.barCode
    }
    fun getSalePrice():String{
        return this.salePrice
    }
    fun getStock():String{
        return this.stock
    }
}