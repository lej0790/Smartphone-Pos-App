package com.example.icia24hours

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_goods_registration.*
import org.jetbrains.anko.toast

class GoodsRegistrationActivity : AppCompatActivity() {

    lateinit var myHelperGR:MainActivity.MyDBHelper
    lateinit var sqlDBGR:SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_registration)
        title = "상품등록"

        var registrationFlag:Boolean = true

        myHelperGR = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)
        sqlDBGR = myHelperGR.writableDatabase

        goodsRegistrationBtn.setOnClickListener {
            if((goodsName.text.toString() == "") || (category.text.toString() == "") ||
                (salePrice.text.toString() == "") || (unitPrice.text.toString() == "") ||
                (barCode.text.toString() == "") || (stock.text.toString() == "")){

                toast("입력하지 않은 상품정보가 있습니다.")

            }else{

                sqlDBGR = myHelperGR.readableDatabase
                val c1: Cursor
                c1 = sqlDBGR.rawQuery("select * from GoodsTBL", null)
                var checkSameBarCode:Int

                while(c1.moveToNext()){
                    val existingBarCode:String = c1.getString(4)
                    val insertBarCode:String = barCode.text.toString()
                    if(existingBarCode == insertBarCode){
                        toast("이미 등록되어 있는 상품입니다.")
                        registrationFlag=false
                        break
                    }
                }
                c1.close()

                if(registrationFlag) {
                    sqlDBGR.execSQL(
                        "insert into GoodsTBL values('" + category.text.toString() + "','" +
                                goodsName.text.toString() + "','" + salePrice.text.toString() + "','" +
                                unitPrice.text.toString() + "','" + barCode.text.toString() + "','" + stock.text.toString() + "')"
                    )
                    toast("상품이 등록되었습니다")
                }
                registrationFlag = true
            }
        }

        goodsRegistrationInitBtn.setOnClickListener {
            goodsName.setText("")
            category.setText("")
            salePrice.setText("")
            unitPrice.setText("")
            barCode.setText("")
            stock.setText("")

        }

    }
}
