package com.example.icia24hours

class ListViewItemSaleStatement {
    private lateinit var goodsNameStr:String
    private lateinit var barCodeStr:String
    private lateinit var amountStr:String
    private lateinit var salePriceStr:String

    fun setGoodsName(goodsName:String){
        this.goodsNameStr=goodsName
    }
    fun setBarCode(barCode:String){
        this.barCodeStr=barCode
    }
    fun setAmount(amount:String){
        this.amountStr=amount
    }
    fun setSalePrice(salePrice:String){
        this.salePriceStr=salePrice
    }

    fun getGoodsName():String{
        return this.goodsNameStr
    }
    fun getBarCode():String{
        return this.barCodeStr
    }

    fun getAmount():String{
        return this.amountStr
    }
    fun getSalePrice():String{
        return this.salePriceStr
    }

}