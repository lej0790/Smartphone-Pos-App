package com.example.icia24hours

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.icu.text.DecimalFormat
import android.icu.text.SimpleDateFormat
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_sales_statement.*
import kotlinx.android.synthetic.main.listview_item_salesstatement.view.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import java.util.*

class SalesStatement : AppCompatActivity() {

    //상품정보 데이터베이스 준비
    lateinit var myHelper: MainActivity.MyDBHelper
    lateinit var sqlDB: SQLiteDatabase
    //상품정보 데이터베이스 준비 끝

    var checkFlag:Boolean = false

    //전표용 데이터베이스 준비
    lateinit var myHelperSS: SaleRegistration.MyDBHelperSaleStatement
    lateinit var sqlDBSS: SQLiteDatabase
    //전표용 데이터베이스 준비 끝

    //판매내역용 데이터베이스 준비
    lateinit var myHelperSBD: MainActivity.MyDBHelperSaleBreakDown
    lateinit var sqlDBSBD:SQLiteDatabase
    //판매내역용 데이터베이스 준비

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sales_statement)
        title = "전표"

        var totalSumSS = 0
        val myFormatter: DecimalFormat = DecimalFormat("###,###,###,###,###")


        //판매내역용 데이터베이스 준비완료
        myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
        sqlDBSBD = myHelperSBD.writableDatabase
        //판매내역용 데이터베이스 준비완료 끝



        //리스트뷰에 결제목록 나열하는 부분
        val listview: ListView
        val adapter: ListViewAdapterSaleStatement

        adapter = ListViewAdapterSaleStatement()

        listview = findViewById(R.id.lvForSaleStatement)
        listview.adapter = adapter

        myHelperSS = SaleRegistration.MyDBHelperSaleStatement(this, "SaleStatementDB", null, 1)
        sqlDBSS = myHelperSS.readableDatabase

        val c: Cursor
        c = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)

        while (c.moveToNext()) {
            adapter.addItem(
                c.getString(0),
                c.getString(2),
                c.getString(3),
                myFormatter.format((c.getString(1).toInt()))
            )
            totalSumSS += (c.getString(1).toInt()) * (c.getString(3).toInt())
        }
        c.close()
        //리스트뷰에 결제목록 나열하는 부분 끝

        //합계 표시하는 부분
        val formattedStringPrice = myFormatter.format(totalSumSS)
        totalSum.text = formattedStringPrice
        //합계 표시하는 부분 끝

        //결제목록을 나열하는 리스트뷰에서 하나를 선택할 시 결제목록에서 사라지는 부분
        listview.onItemClickListener = AdapterView.OnItemClickListener { _, view, position, id ->
            //상품목록 데이터베이스에 해당 상품재고 +1 추가
            sqlDB = myHelper.readableDatabase
            val c1: Cursor = sqlDB.rawQuery("select * from GoodsTBL", null)
            while (c1.moveToNext()) {
                if (c1.getString(4) == view.barCodeSS.text.toString()) {
                    sqlDB = myHelper.writableDatabase
                    sqlDB.execSQL(
                        "update GoodsTBL set stock='" + ((c1.getString(5).toInt()) + 1).toString() +
                                "' where barCode='" + c1.getString(4) + "'"
                    )
                }
            }
            c1.close()
            //상품목록 데이터베이스에 해당 상품재고 +1 추가 끝

            //전표데이터베이스에서 결제목록에서 선택한 상품을 삭제하는 부분

            sqlDBSS = myHelperSS.readableDatabase
            val c2: Cursor = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)
            while (c2.moveToNext()) {
                if (c2.getString(2) == view.barCodeSS.text.toString()) {
                    //오류뜨면 아래에서 뜰 듯하다. 바코드가 중복되어있는게 있으면 구별을 못해서일 듯하다

                    break
                }
            }
            c2.close()

            //전표데이터베이스에서 결제목록에서 선택한 상품을 삭제하는 부분 끝

        }

        //결제목록을 나열하는 리스트뷰에서 하나를 선택할 시 결제목록에서 사라지는 부분 끝

        //결제취소부분
        paymentCancelBtn.setOnClickListener {
            //전표테이블 삭제하기 전에 다시 상품데이터베이스에 더해주기
            sqlDBSS = myHelperSS.readableDatabase

            val c24: Cursor
            c24 = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)
            while (c24.moveToNext()) {
                val barCode: String = c24.getString(2)
                val amountAdd: String = c24.getString(3)
                //여기서 바코드가 널이나 공백이면 상품데이터베이스에 추가 안해도된다(근데 공백인거 체크 안해줘도 될 듯 만약 오류나면 아래 바로 있는 if문 지우자)
                //else의 바디 내용은 놔둬야됨
                myHelper = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)//이거 안써주면 동작을 안한다!!!!
                sqlDB = myHelper.readableDatabase
                val c20: Cursor = sqlDB.rawQuery("select * from GoodsTBL", null)
                while (c20.moveToNext()) {

                    if (c20.getString(4) == barCode) {
                        val stock: String = c20.getString(5)
                        val finalStock: String = (stock.toInt() + amountAdd.toInt()).toString()
                        sqlDB = myHelper.writableDatabase
                        sqlDB.execSQL(
                            "update GoodsTBL set stock='" + finalStock +
                                    "' where barCode ='" + barCode + "'"
                        )

                        checkFlag = true

                    }
                }
                c20.close()


            }//이 while문은 바코드가 없을 때 즉, 결제된 상품이 없을 때만 브레이크고 그 이외에는 브레이크 해주면 안된다!! 결제목록에 있는 모든 것들을 상품데이터베이스에 넣어줘야하기 때문이다
            c24.close()

            if(checkFlag) {
                toast("결제취소가 완료되었습니다.")
                checkFlag = false
            }

            //전표테이블내용 다 삭제하고 다시 전표액티비티에 전표내용 출력
            sqlDBSS = myHelperSS.writableDatabase
            sqlDBSS.execSQL("delete from SaleStatementTBL")

            listview.removeAllViewsInLayout()
            val listview: ListView
            val adapter: ListViewAdapterSaleStatement

            adapter = ListViewAdapterSaleStatement()

            listview = findViewById(R.id.lvForSaleStatement)
            listview.adapter = adapter

            val c: Cursor
            c = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)

            while (c.moveToNext()) {
                adapter.addItem(
                    c.getString(0),
                    c.getString(2),
                    c.getString(3),
                    myFormatter.format((c.getString(1).toInt()))
                )
                totalSumSS += (c.getString(1).toInt()) * (c.getString(3).toInt())
            }
            c.close()
            totalSum.text = "0"


        }

        //결제버튼을 누르는 부분(시스템시간으로 주문번호 만들어야한다)
        paymentBtn.setOnClickListener {

            //전표 데이터베이스에서 각 상품별 상품명, 판매가, 바코드, 수량 가져오고
            // 시스템시간 가져와 주문번호변수에 저장하자. 또한 시스템시간을 변형하여 년월일요일시간으로 만들어 String 타입 변수에 저장.
            //주문번호, 날짜, 상품명, 판매가, 바코드 수량을 판매내역 테이블에 저장
            val mFormat: SimpleDateFormat = SimpleDateFormat("yyyy년 MM월 dd일 hh:mm:ss")
            val time =System.currentTimeMillis()
            var mDate = Date(time)
            var orderTime = mFormat.format(mDate) //주문시간

            var orderNumberSBDStr = System.currentTimeMillis().toString()

            myHelperSS = SaleRegistration.MyDBHelperSaleStatement(this, "SaleStatementDB", null, 1)
            sqlDBSS = myHelperSS.readableDatabase

            val c45:Cursor = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)
            while(c45.moveToNext()){
                val goodsName = c45.getString(0)
                val salePrice = c45.getString(1)
                val barCode = c45.getString(2)
                val amount = c45.getString(3)
                myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
                sqlDBSBD = myHelperSBD.writableDatabase
                sqlDBSBD.execSQL("insert into SaleBreakDownTBL values('" + orderNumberSBDStr +
                        "','" + orderTime + "','" + goodsName +"','"+salePrice+"','"+barCode+"','"+amount+"')")
            }
            c45.close()



//            sqlDBSS = myHelperSS.writableDatabase
//            sqlDBSS.execSQL(
//                "insert into SaleStatementTBL values('" + goodsName +
//                        "','" + salePrice + "','" + barCode + "','" + amount + "')"
//            )

            sqlDBSS = myHelperSS.writableDatabase
            sqlDBSS.execSQL("delete from SaleStatementTBL")

            listview.removeAllViewsInLayout()
            val listview: ListView
            val adapter: ListViewAdapterSaleStatement

            adapter = ListViewAdapterSaleStatement()

            listview = findViewById(R.id.lvForSaleStatement)
            listview.adapter = adapter

            val c: Cursor
            c = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)

            while (c.moveToNext()) {
                adapter.addItem(
                    c.getString(0),
                    c.getString(2),
                    c.getString(3),
                    myFormatter.format((c.getString(1).toInt()))
                )
                totalSumSS += (c.getString(1).toInt()) * (c.getString(3).toInt())
            }
            c.close()
            totalSum.text = "0"

            toast("결제가 완료되었습니다.")

        }

        changeToBarCode.setOnClickListener {
            startActivity<BarCodeReaderActivity>()
        }


    }
}
