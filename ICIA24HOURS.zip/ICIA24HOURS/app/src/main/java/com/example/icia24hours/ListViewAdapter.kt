package com.example.icia24hours

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class ListViewAdapter:BaseAdapter() {
    private var listViewItemList:ArrayList<ListViewItem> = ArrayList()

    override fun getCount(): Int {
        return listViewItemList.size
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val pos:Int = position
        val context: Context = parent!!.getContext()
        var convertView:View? = convertView

        if(convertView == null){
            val inflater:LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.listview_item, parent, false)
        }

        var iconImageView:ImageView = convertView!!.findViewById(R.id.imageView) as ImageView
        var titleTextView: TextView = convertView.findViewById(R.id.textView) as TextView

        var listViewItem:ListViewItem = listViewItemList.get(position)

        iconImageView.setImageDrawable(listViewItem.getIcon())
        titleTextView.setText(listViewItem.getTitle())

        return convertView
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return listViewItemList.get(position)
    }

    fun addItem(icon:Drawable, title:String){
        var item:ListViewItem = ListViewItem()

        item.setIcon(icon)
        item.setTitle(title)

        listViewItemList.add(item)
    }

}