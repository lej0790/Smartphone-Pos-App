package com.example.icia24hours

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.widget.AdapterView
import android.widget.ListView
import kotlinx.android.synthetic.main.listviewitemgoodslist.view.*
import org.jetbrains.anko.toast



class GoodsDelete : AppCompatActivity() {

    lateinit var myHelper:MainActivity.MyDBHelper
    lateinit var sqlDB: SQLiteDatabase
    lateinit var listview: ListView
    lateinit var adapterDelete:ListViewAdapter2


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_delete)
        title = "상품삭제"

        var deleteFlag:Boolean = true

        adapterDelete = ListViewAdapter2()

        listview = findViewById(R.id.lvForGoodsDelete)
        listview.adapter = adapterDelete

        myHelper = MainActivity.MyDBHelper(this, "GoodsDB",null,1)
        sqlDB = myHelper.readableDatabase

        val c2: Cursor
        c2 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

        while(c2.moveToNext()){

            adapterDelete.addItem(c2.getString(1),c2.getString(4),
                c2.getString(2),c2.getString(5))

        }
        c2.close()

        listview.onItemClickListener = AdapterView.OnItemClickListener { _, view, position, id ->
//            view.barCodeTV.text.toString()
            sqlDB = myHelper.readableDatabase

            val c3: Cursor
            c3 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

            while(c3.moveToNext()){
                if(c3.getString(4) == view.barCodeTV.text.toString()){
                    sqlDB = myHelper.writableDatabase
                    sqlDB.execSQL("delete from GoodsTBL where (barCode='"+view.barCodeTV.text.toString()+"')")
                    toast("상품이 삭제되었습니다.")
                    deleteFlag = false
                    listview.removeAllViewsInLayout()
                    adapterDelete = ListViewAdapter2()
                    listview.adapter = adapterDelete
                    sqlDB = myHelper.readableDatabase

                    val c4: Cursor
                    c4 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

                    while(c4.moveToNext()){

                        adapterDelete.addItem(c4.getString(1),c4.getString(4),
                            c4.getString(2),c4.getString(5))

                    }
                    c4.close()

                    break
                }
            }
            c3.close()


            if(deleteFlag){
                toast("해당하는 상품이 없어서 삭제할 수 없습니다")
            }

            deleteFlag = true

            adapterDelete.notifyDataSetChanged()
            listview.adapter = adapterDelete

//            sqlDB = myHelper.readableDatabase
//
//            val c4: Cursor
//            c4 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?
//
//            while(c4.moveToNext()){
//
//                adapter.addItem(c4.getString(1),c4.getString(4),
//                    c4.getString(2),c4.getString(5))
//
//            }
//            c4.close()
        }

    }



}
