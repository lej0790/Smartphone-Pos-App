package com.example.icia24hours

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.icu.text.DecimalFormat
import android.icu.text.NumberFormat
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_sale_registration.*
import kotlinx.android.synthetic.main.listviewitemgoodslist.view.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class SaleRegistration : AppCompatActivity() {

    //상품판매등록 액티비티의 리스트뷰에 상품 목록을 띄우기 위한 것이다
    lateinit var myHelper: MainActivity.MyDBHelper
    lateinit var sqlDB: SQLiteDatabase

    //전표용 데이터베이스를 만들기 위한 것이다
    lateinit var myHelperSS: MyDBHelperSaleStatement
    lateinit var sqlDBSS: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
//        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sale_registration)
        title = "판매등록"

        var totalSum:Int = 0
        val myFormatter: DecimalFormat = DecimalFormat("###,###,###,###,###") // 돈 표시 3자리 콤마 마추기 위한 것
        var checkFlag:Boolean = true

        //전표용 데이터 베이스 구동
        myHelperSS = MyDBHelperSaleStatement(this, "SaleStatementDB", null, 1)
        sqlDBSS = myHelperSS.writableDatabase
//        myHelperSS.onUpgrade(sqlDBSS,1,2)

        //총결제가격을 표시하는 부분(3자리수 콤마 적용)
        sqlDBSS = myHelperSS.readableDatabase
        val c4: Cursor
        c4 = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)
        while (c4.moveToNext()) {
            totalSum += (c4.getString(1).toInt())*(c4.getString(3).toInt())
        }
        c4.close()

        val formattedStringPrice = myFormatter.format(totalSum)
        totalPaymentPrice.text = formattedStringPrice
        //총결제가격을 표시하는 부분(3자리수 콤마 적용) 끝

        //상품판매등록액티비티에 상품 목록 띄우는 부분
        var listview: ListView
        var adapter: ListViewAdapter2
        adapter = ListViewAdapter2()

        listview = findViewById(R.id.lvForSaleRegistration)
        listview.adapter = adapter

        myHelper = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)
        sqlDB = myHelper.readableDatabase

        val c2: Cursor
        c2 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

        while (c2.moveToNext()) {

            adapter.addItem(
                c2.getString(1), c2.getString(4),
                c2.getString(2), c2.getString(5)
            )

        }

        c2.close()
        //상품판매등록액티비티에 상품 목록 띄우는 부분 끝

        listview.onItemClickListener = AdapterView.OnItemClickListener { _, view, position, id ->
            //리스트뷰에서 선택한 것들을 전표데이터베이스에 저장한다
//            view.barCodeTV.text.toString()
            sqlDB = myHelper.readableDatabase
            val c: Cursor = sqlDB.rawQuery("select * from GoodsTBL", null)
            while (c.moveToNext()) {

                //전표테이블에 추가하는 부분
                if (view.barCodeTV.text.toString() == c.getString(4)) {

                    if(c.getString(5).toInt() > 0) {//재고가 남아있는지 확인하는 부분
                        val goodsName = c.getString(1)
                        val salePrice = c.getString(2)
                        val barCode = c.getString(4)
                        val amount:Int = 1
                        totalSum += salePrice.toInt()

                        val formattedStringPrice2 = myFormatter.format(totalSum)
                        totalPaymentPrice.text = formattedStringPrice2

                        //전표테이블에 선택한 상품의 바코드와 같은게 있다면 그 전표테이블의 상품의 수량에 1 더하기!!
                        sqlDBSS = myHelperSS.readableDatabase
                        val c13:Cursor = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)
                        while(c13.moveToNext()){
                            if(c13.getString(2) == view.barCodeTV.text.toString()){
                                var changedAmount:Int = (c13.getString(3).toInt()) + amount


                                sqlDBSS = myHelperSS.writableDatabase
                                sqlDBSS.execSQL("update SaleStatementTBL set amount='"+changedAmount.toString() +
                                        "' where barCode ='"+view.barCodeTV.text.toString()+"'")
                                checkFlag = false
                                break
                            }
                        }
                        //전표테이블에 선택한 상품의 바코드와 같은게 있다면 그 전표테이블의 상품의 수량에 1 더하기 끝
                        c13.close()

                        if(checkFlag) {
                            sqlDBSS = myHelperSS.writableDatabase
                            sqlDBSS.execSQL(
                                "insert into SaleStatementTBL values('" + goodsName +
                                        "','" + salePrice + "','" + barCode + "','" + amount + "')"
                            )
                        }

                        checkFlag = true

                        toast("전표에 선택하신 상품이 추가되었습니다.")
                        //전표 테이블에 추가하는 부분 끝

                        //goodsTBL에 변경사항 적용하기
                        sqlDB = myHelper.writableDatabase
                        sqlDB.execSQL(
                            "update GoodsTBL set stock='" + ((c.getString(5).toInt()) - 1).toString() +
                                    "' where barCode='" + c.getString(4) + "'"
                        )

                        //상품판매등록에서 리스트뷰의 뷰들 다 삭제하고 goodsTBL에서 정보 뽑아와 다시 상품판매등록의 리스트뷰에 보여주기
                        listview.removeAllViewsInLayout()
                        var listview: ListView
                        var adapter: ListViewAdapter2
                        adapter = ListViewAdapter2()

                        listview = findViewById(R.id.lvForSaleRegistration)
                        listview.adapter = adapter

                        myHelper = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)
                        sqlDB = myHelper.readableDatabase

                        val c2: Cursor
                        c2 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

                        while (c2.moveToNext()) {

                            adapter.addItem(
                                c2.getString(1), c2.getString(4),
                                c2.getString(2), c2.getString(5)
                            )
                        }
                        c2.close() //여기까지!!!
                        break
                    }else{
                        toast("선택하신 상품의 재고가 부족합니다.")
                        break
                    }
                }

            }
            c.close()
        }



        salesStatementBtn.setOnClickListener {
            startActivity<SalesStatement>()
        }
    }

    //전표용 데이터베이스를 만들기 위한 것이다. 삭제하지 말자.
    class MyDBHelperSaleStatement(
        context: Context?,
        name: String?,
        factory: SQLiteDatabase.CursorFactory?,
        version: Int
    ) :
        SQLiteOpenHelper(context, name, factory, version) {
        override fun onCreate(db: SQLiteDatabase?) {
            db?.execSQL(
                "create table SaleStatementTBL(goodsName char(30), salePrice char(30), " +
                        "barCode char(30) primary key, amount char(30))"
            )
        }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
            db?.execSQL("drop table if exists SaleStatementTBL")
            onCreate(db)
        }
    }
}
