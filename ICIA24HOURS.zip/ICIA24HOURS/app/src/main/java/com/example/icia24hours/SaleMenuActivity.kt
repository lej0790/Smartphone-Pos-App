package com.example.icia24hours

import android.graphics.drawable.Drawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.widget.AdapterView
import android.widget.ListView
import org.jetbrains.anko.startActivity

class SaleMenuActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sale_menu)

        title = "판매관련메뉴"

        var listviewSaleMenu: ListView
        var adapterSaleMenu:ListViewAdapter

        adapterSaleMenu = ListViewAdapter()

        listviewSaleMenu = findViewById(R.id.lvForSaleMenu)
        listviewSaleMenu.adapter = adapterSaleMenu

        adapterSaleMenu.addItem(ContextCompat.getDrawable(this, R.drawable.ic_shopping_basket_black_24dp) as Drawable,"판매등록")
        adapterSaleMenu.addItem(ContextCompat.getDrawable(this, R.drawable.ic_reorder_black_24dp) as Drawable,"판매내역")
        adapterSaleMenu.addItem(ContextCompat.getDrawable(this,R.drawable.ic_receipt_black_24dp) as Drawable, "매출액")


        listviewSaleMenu.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            when(position){
                0 -> {
                    startActivity<SaleRegistration>()
                }

                1 -> {
                    startActivity<SaleBreakDown>()
                }

                2 -> {
                    startActivity<TotalSalesAmount>()
                }

            }
        }
    }
}
