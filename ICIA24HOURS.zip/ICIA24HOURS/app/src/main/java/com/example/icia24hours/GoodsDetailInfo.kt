package com.example.icia24hours

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_goods_detail_info.*

class GoodsDetailInfo : AppCompatActivity() {
    lateinit var myHelperList: MainActivity.MyDBHelper
    lateinit var sqlDBList: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_detail_info)
        title = "상품상세정보"

        myHelperList = MainActivity.MyDBHelper(this, "GoodsDB",null,1)
        sqlDBList = myHelperList.readableDatabase

        var goodsBarCode = intent.getStringExtra("barCode")

        val c3: Cursor
        c3 = sqlDBList.rawQuery("select * from GoodsTBL", null) // ;써야하나?

        while(c3.moveToNext()){

            if(c3.getString(4) == goodsBarCode){
                goodsNameI.setText(c3.getString(1))
                categoryI.setText(c3.getString(0))
                salePriceI.setText(c3.getString(2))
                unitPriceI.setText(c3.getString(3))
                barCodeI.setText(c3.getString(4))
                stockI.setText(c3.getString(5))
            }

        }
        c3.close()
    }
}
