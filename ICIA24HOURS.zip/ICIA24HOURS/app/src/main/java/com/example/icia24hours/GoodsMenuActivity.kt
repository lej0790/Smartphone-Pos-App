package com.example.icia24hours

import android.graphics.drawable.Drawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.widget.AdapterView
import android.widget.ListView
import org.jetbrains.anko.startActivity

class GoodsMenuActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_menu)

        title = "상품관련메뉴"

        var listview:ListView
        var adapter:ListViewAdapter

        adapter = ListViewAdapter()

        listview = findViewById(R.id.listView)
        listview.adapter = adapter

        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_book_black_24dp) as Drawable,"상품등록")
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_list_black_24dp) as Drawable,"상품목록")
        adapter.addItem(ContextCompat.getDrawable(this,R.drawable.ic_autorenew_black_24dp) as Drawable, "상품수정")
        adapter.addItem(ContextCompat.getDrawable(this,R.drawable.ic_delete_black_24dp) as Drawable, "상품삭제")

        listview.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            when(position){
                0 -> {
                    startActivity<GoodsRegistrationActivity>()
                }

                1 -> {
                    startActivity<GoodsList>()
                }

                2 -> {
                    startActivity<GoodsRevise>()
                }

                3 -> {
                    startActivity<GoodsDelete>()
                }
            }
        }
    }
}
