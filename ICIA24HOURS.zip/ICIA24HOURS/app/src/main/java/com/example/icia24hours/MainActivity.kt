package com.example.icia24hours

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.icu.text.SimpleDateFormat
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import java.util.*

class MainActivity : AppCompatActivity() {



    //상품 데이터베이스 만들기 준비
    lateinit var myHelper:MyDBHelper
    lateinit var sqlDB:SQLiteDatabase
    //상품 데이터베이스 만들기 준비 끝

    //판매내역 데이터베이스 만들기 준비
    lateinit var myHelperSBD:MyDBHelperSaleBreakDown
    lateinit var sqlDBSBD:SQLiteDatabase
    //판매내역 데이터베이스 만들기 준비 끝

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //상품 데이터베이스 만들기 시작
        myHelper = MyDBHelper(this, "GoodsDB", null, 1)
        sqlDB = myHelper.writableDatabase
//        myHelper.onUpgrade(sqlDB,1,2)
        //상품 데이터베이스 만들기 끝

        myHelperSBD = MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
        sqlDBSBD = myHelperSBD.writableDatabase
//        myHelperSBD.onUpgrade(sqlDBSBD,1,2)


        goodsMenuBtn.setOnClickListener {
            startActivity<GoodsMenuActivity>()
        }

        saleMenuBtn.setOnClickListener {
            startActivity<SaleMenuActivity>()
        }

        barCodeReader.setOnClickListener {
            startActivity<BarCodeReaderActivity>()
        }

        programExitBtn.setOnClickListener {
            System.exit(0)
        }
    }

    class MyDBHelper(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int) :
        SQLiteOpenHelper(context, name, factory, version) {
        override fun onCreate(db: SQLiteDatabase?) {
            db?.execSQL("create table GoodsTBL(category char(30), goodsName char(30), " +
                    "salePrice char(30), unitPrice char(15,2), barCode char(30) primary key, stock char(30))")
        }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
//            db?.execSQL("drop table if exists GoodsTBL")
//            onCreate(db)
        }
    }

    class MyDBHelperSaleBreakDown(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int) :
        SQLiteOpenHelper(context, name, factory, version) {
        override fun onCreate(db: SQLiteDatabase?) {
            db?.execSQL("create table SaleBreakDownTBL(orderNumber char(30) primary key, " +
                    "date char(30), goodsName char(30), salePrice char(30), barCode char(30) primary key, amount char(30))")
        }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
            db?.execSQL("drop table if exists SaleBreakDownTBL")
            onCreate(db)
        }
    }
}
