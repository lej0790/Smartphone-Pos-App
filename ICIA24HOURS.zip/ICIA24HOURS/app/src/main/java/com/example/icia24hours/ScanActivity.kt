package com.example.icia24hours

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.zxing.Result
import kotlinx.android.synthetic.main.activity_bar_code_reader.*
import me.dm7.barcodescanner.zxing.ZXingScannerView
import org.jetbrains.anko.toast
import android.media.ToneGenerator
import android.media.AudioManager
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_sale_registration.*
import kotlinx.android.synthetic.main.listviewitemgoodslist.view.*


class ScanActivity : AppCompatActivity(), ZXingScannerView.ResultHandler {

    private lateinit var mScannerView:ZXingScannerView

    //상품판매등록 액티비티의 리스트뷰에 상품 목록을 띄우기 위한 것이다
    lateinit var myHelper: MainActivity.MyDBHelper
    lateinit var sqlDB: SQLiteDatabase

    //전표용 데이터베이스를 만들기 위한 것이다
    lateinit var myHelperSS: SaleRegistration.MyDBHelperSaleStatement
    lateinit var sqlDBSS: SQLiteDatabase


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mScannerView = ZXingScannerView(this)
        setContentView(mScannerView)
    }

    override fun onResume() {
        super.onResume()
        mScannerView.setResultHandler(this)
        mScannerView.startCamera()
    }

    override fun onPause() {
        super.onPause()
        mScannerView.stopCamera()
    }

    override fun handleResult(p0: Result?) {
        Log.d("바코드",p0!!.getText())
        var checkFlag:Boolean = true
        val resultBarCode:String = p0.getText()


        //바코드 찍을 때 소리나게 하는 부분
        //https://stackoverflow.com/questions/29509010/how-to-play-a-short-beep-to-android-phones-loudspeaker-programmatically/29509305 참고고
       val toneGen1 = ToneGenerator(AudioManager.STREAM_MUSIC, 1000)
        toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP, 200)
//        tvresult.setText(p0.toString())
//        onBackPressed()

        //전표용 데이터 베이스 구동
        myHelperSS = SaleRegistration.MyDBHelperSaleStatement(this, "SaleStatementDB", null, 1)
        sqlDBSS = myHelperSS.writableDatabase

        myHelper = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)
        sqlDB = myHelper.readableDatabase

        sqlDB = myHelper.readableDatabase
        val c: Cursor = sqlDB.rawQuery("select * from GoodsTBL", null)
        while (c.moveToNext()) {

            //전표테이블에 추가하는 부분
            if (resultBarCode == c.getString(4)) {

                if(c.getString(5).toInt() > 0) {//재고가 남아있는지 확인하는 부분
                    val goodsName = c.getString(1)
                    val salePrice = c.getString(2)
                    val barCode = c.getString(4)
                    val amount:Int = 1
//                    totalSum += salePrice.toInt()

//                    val formattedStringPrice2 = myFormatter.format(totalSum)
//                    totalPaymentPrice.text = formattedStringPrice2

                    //전표테이블에 선택한 상품의 바코드와 같은게 있다면 그 전표테이블의 상품의 수량에 1 더하기!!
                    sqlDBSS = myHelperSS.readableDatabase
                    val c13: Cursor = sqlDBSS.rawQuery("select * from SaleStatementTBL", null)
                    while(c13.moveToNext()){
                        if(c13.getString(2) == resultBarCode){
                            var changedAmount:Int = (c13.getString(3).toInt()) + amount


                            sqlDBSS = myHelperSS.writableDatabase
                            sqlDBSS.execSQL("update SaleStatementTBL set amount='"+changedAmount.toString() +
                                    "' where barCode ='"+resultBarCode+"'")
                            checkFlag = false
                            break
                        }
                    }
                    //전표테이블에 선택한 상품의 바코드와 같은게 있다면 그 전표테이블의 상품의 수량에 1 더하기 끝
                    c13.close()

                    if(checkFlag) {
                        sqlDBSS = myHelperSS.writableDatabase
                        sqlDBSS.execSQL(
                            "insert into SaleStatementTBL values('" + goodsName +
                                    "','" + salePrice + "','" + barCode + "','" + amount + "')"
                        )
                    }

                    checkFlag = true

                    //전표 테이블에 추가하는 부분 끝

                    //goodsTBL에 변경사항 적용하기
                    sqlDB = myHelper.writableDatabase
                    sqlDB.execSQL(
                        "update GoodsTBL set stock='" + ((c.getString(5).toInt()) - 1).toString() +
                                "' where barCode='" + c.getString(4) + "'"
                    )
                    var checkMode:String ="1"
                    val intent = Intent(this, BarCodeReaderActivity::class.java)
                    intent.putExtra("resultBarCode", resultBarCode)
                    intent.putExtra("checkMode", checkMode)

                    startActivity(intent)

                    break
                }else{
                    var checkMode:String = "2"
                    val intent = Intent(this, BarCodeReaderActivity::class.java)
                    intent.putExtra("checkMode", checkMode)
                    startActivity(intent)

                    break
                }
            }else{
                var checkMode:String = "3"
                val intent = Intent(this, BarCodeReaderActivity::class.java)
                intent.putExtra("checkMode", checkMode)
                startActivity(intent)
            }

        }
        c.close()



    }
}
