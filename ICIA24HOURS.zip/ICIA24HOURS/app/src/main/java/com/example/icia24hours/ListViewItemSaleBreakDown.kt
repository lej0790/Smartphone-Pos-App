package com.example.icia24hours

class ListViewItemSaleBreakDown {
    private lateinit var paymentTimeStr:String
    private lateinit var orderNumberStr:String
    private lateinit var totalSumSBDStr:String

    fun setPaymentTime(paymentTime:String){
        paymentTimeStr = paymentTime
    }

    fun setOrderNumber(orderNumber:String){
        orderNumberStr = orderNumber
    }

    fun setTotalSumSBD(totalSumSBD:String){
        totalSumSBDStr = totalSumSBD
    }

    fun getPaymentTime():String{
        return this.paymentTimeStr
    }

    fun getOrderNumber():String{
        return this.orderNumberStr
    }

    fun getTotalSumSBD():String{
        return this.totalSumSBDStr
    }

}