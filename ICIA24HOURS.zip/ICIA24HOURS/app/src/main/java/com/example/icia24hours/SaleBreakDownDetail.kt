package com.example.icia24hours

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.icu.text.DecimalFormat
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_sale_break_down_detail.*

class SaleBreakDownDetail : AppCompatActivity() {

    lateinit var myHelperSBD: MainActivity.MyDBHelperSaleBreakDown
    lateinit var sqlDBSBD: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sale_break_down_detail)
        title = "판매내역상세"

        val gettingOrderNumber:String = intent.getStringExtra("orderNumber")
        var totalSum:Int = 0
        var date:String = ""
        var orderNumberStr:String =""
        val myFormatter: DecimalFormat = DecimalFormat("###,###,###,###,###")

        var listview: ListView
        var adapter: ListViewAdapterSaleStatement
        adapter = ListViewAdapterSaleStatement()

        listview = findViewById(R.id.lvForSBDD)
        listview.adapter = adapter

        myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
        sqlDBSBD = myHelperSBD.readableDatabase

        val c:Cursor = sqlDBSBD.rawQuery("select * from SaleBreakDownTBL", null)

        while (c.moveToNext()){
            if(c.getString(0) == gettingOrderNumber){
                val goodsName = c.getString(2)
                val salePrice = c.getString(3)
                val barCode = c.getString(4)
                val amountD = c.getString(5)

                date =c.getString(1)
                orderNumberStr = c.getString(0)
                adapter.addItem(goodsName,barCode,amountD,salePrice)

                totalSum += (c.getString(3).toInt())*(c.getString(5).toInt())
//                adapter.addItem()
            }
        }

        totalSumSBDD.text = myFormatter.format(totalSum)
        orderNumber.text = orderNumberStr
        paymentTime.setText(date)




//        val c55:Cursor = sqlDBSBD.rawQuery("select orderNumber, date from SaleBreakDownTBL group by orderNumber",null)
//        while(c55.moveToNext()){
//            //c55.getString(0)
//            myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
//            sqlDBSBD = myHelperSBD.readableDatabase
//            var totalSumPerPerson:Int = 0
//            val c:Cursor = sqlDBSBD.rawQuery("select * from SaleBreakDownTBL", null)
//            while(c.moveToNext()){
//                if(c55.getString(0) == c.getString(0)){
//                    var totalPrice = (c.getString(3).toInt())*(c.getString(5).toInt())
//                    totalSumPerPerson += totalPrice
//                }
////                adapter.addItem(c.getString(1),c.getString(0),c.getString(2))
//            }
//            c.close()
//
//            adapter.addItem(c55.getString(1),c55.getString(0),totalSumPerPerson.toString())
//
//        }
//        c55.close()


    }
}
