package com.example.icia24hours

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_bar_code_reader.*
import org.jetbrains.anko.*

class BarCodeReaderActivity : AppCompatActivity() {

    //https://demonuts.com/scan-barcode-qrcode/ 라는 사이트에서 바코드 만드는 거 참고했다!!!
    private lateinit var btn: Button
    lateinit var tvresult: TextView
    val REQUEST_READ_CAMERA = 1000

    lateinit var myHelper: MainActivity.MyDBHelper
    lateinit var sqlDB: SQLiteDatabase


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bar_code_reader)
        title = "바코드리더기"

        getCameraPermission()


        btn = findViewById(R.id.btn)

        btn.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                startActivity<ScanActivity>()
            }
        })


        if(intent.getStringExtra("checkMode") == "1") {
            if (intent.getStringExtra("resultBarCode") != null) {
                val getResultBarCode: String = intent.getStringExtra("resultBarCode")
                myHelper = MainActivity.MyDBHelper(this, "GoodsDB", null, 1)
                sqlDB = myHelper.readableDatabase

                val c2: Cursor
                c2 = sqlDB.rawQuery("select * from GoodsTBL", null) // ;써야하나?

                while (c2.moveToNext()) {
                    if (c2.getString(4) == intent.getStringExtra("resultBarCode")) {
                        toast("전표에 " + c2.getString(1) + " 추가")
                        break
                    }
                }
                c2.close()
            }
        }else if(intent.getStringExtra("checkMode") == "2"){
            toast("해당 상품의 재고가 부족합니다.")
        }else if(intent.getStringExtra("checkMode") == "3"){
            toast("해당하는 상품이 존재하지 않습니다.")
        }


        ssBtn.setOnClickListener {
            startActivity<SalesStatement>()
        }
    }

    fun getCameraPermission() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            )
            != PackageManager.PERMISSION_GRANTED
        ) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.CAMERA
                )
            ) {

                alert("mp3 정보를 얻으려면 외부 저장소 권한이 필수로 필요합니다.", "권한이 필요한 이유") {
                    yesButton {
                        ActivityCompat.requestPermissions(
                            this@BarCodeReaderActivity,
                            arrayOf(Manifest.permission.CAMERA),
                            REQUEST_READ_CAMERA
                        );
                    }

                    noButton {

                    }
                }.show()

            } else {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    REQUEST_READ_CAMERA
                )
            }
        } else {

        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_READ_CAMERA -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {

                    toast("권한 거부 됨")

                }
                return
            }
        }
    }


}
