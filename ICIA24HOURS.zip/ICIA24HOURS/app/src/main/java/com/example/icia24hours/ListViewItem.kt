package com.example.icia24hours

import android.graphics.drawable.Drawable

class ListViewItem {
    private lateinit var iconDrawable:Drawable
    private lateinit var titleStr:String

    fun setIcon(icon:Drawable){
        iconDrawable = icon
    }

    fun setTitle(title:String){
        titleStr = title
    }

    fun getIcon():Drawable{
        return this.iconDrawable
    }

    fun getTitle():String{
        return this.titleStr
    }
}