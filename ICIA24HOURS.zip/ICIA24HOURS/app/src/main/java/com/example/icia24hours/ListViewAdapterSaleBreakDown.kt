package com.example.icia24hours

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ListViewAdapterSaleBreakDown: BaseAdapter() {

    private val listViewItemList:ArrayList<ListViewItemSaleBreakDown> = ArrayList<ListViewItemSaleBreakDown>()

    override fun getCount(): Int {
        return listViewItemList.size
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val pos:Int = position
        val context:Context = parent!!.getContext()
        var convertView:View? = convertView

        if(convertView == null){
            val inflater:LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.listview_item_sale_break_down,parent,false)
        }

        val paymentTimeTextView: TextView = convertView!!.findViewById(R.id.paymentTime)
        val orderNumberTextView:TextView = convertView.findViewById(R.id.orderNumber)
        val totalSumSBDTextView:TextView = convertView.findViewById(R.id.totalSumSBD)

        val listViewItem:ListViewItemSaleBreakDown = listViewItemList.get(position)
        paymentTimeTextView.setText(listViewItem.getPaymentTime())
        orderNumberTextView.setText(listViewItem.getOrderNumber())
        totalSumSBDTextView.setText(listViewItem.getTotalSumSBD())

        return convertView
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return listViewItemList.get(position)
    }

    fun addItem(paymentTime:String, orderNumber:String, totalSumSBD:String){
        val item:ListViewItemSaleBreakDown = ListViewItemSaleBreakDown()

        item.setPaymentTime(paymentTime)
        item.setOrderNumber(orderNumber)
        item.setTotalSumSBD(totalSumSBD)

        listViewItemList.add(item)
    }




}