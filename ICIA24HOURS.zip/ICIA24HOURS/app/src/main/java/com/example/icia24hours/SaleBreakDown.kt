package com.example.icia24hours

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.icu.text.DecimalFormat
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Adapter
import android.widget.AdapterView
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_sale_break_down.*
import kotlinx.android.synthetic.main.listview_item_sale_break_down.view.*
import org.jetbrains.anko.toast

class SaleBreakDown : AppCompatActivity() {

    //판매내역 데이터베이스 만들기 준비
    lateinit var myHelperSBD: MainActivity.MyDBHelperSaleBreakDown
    lateinit var sqlDBSBD: SQLiteDatabase
    //판매내역 데이터베이스 만들기 준비 끝


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sale_break_down)
        title = "판매내역"

        val myFormatter: DecimalFormat = DecimalFormat("###,###,###,###,###") // 돈 표시 3자리 콤마 마추기 위한 것
        var listview: ListView
        var adapter: ListViewAdapterSaleBreakDown
        adapter = ListViewAdapterSaleBreakDown()

        listview = findViewById(R.id.lvForSBD)
        listview.adapter = adapter

        myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
        sqlDBSBD = myHelperSBD.readableDatabase

        val c55:Cursor = sqlDBSBD.rawQuery("select orderNumber, date from SaleBreakDownTBL group by orderNumber",null)
        while(c55.moveToNext()){
            //c55.getString(0)
            myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
            sqlDBSBD = myHelperSBD.readableDatabase
            var totalSumPerPerson:Int = 0
            val c:Cursor = sqlDBSBD.rawQuery("select * from SaleBreakDownTBL", null)
            while(c.moveToNext()){
                if(c55.getString(0) == c.getString(0)){
                    var totalPrice = (c.getString(3).toInt())*(c.getString(5).toInt())
                    totalSumPerPerson += totalPrice
                }
//                adapter.addItem(c.getString(1),c.getString(0),c.getString(2))
            }
            c.close()

            adapter.addItem(c55.getString(1),c55.getString(0),myFormatter.format(totalSumPerPerson))

        }
        c55.close()



        saleBreakDownInitBtn.setOnClickListener {
            myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
            sqlDBSBD = myHelperSBD.writableDatabase

            sqlDBSBD.execSQL("delete from SaleBreakDownTBL")

            toast("판매내역이 초기화되었습니다.")

            listview.removeAllViewsInLayout()

            val listview: ListView
            val adapter: ListViewAdapterSaleBreakDown
            adapter = ListViewAdapterSaleBreakDown()

            listview = findViewById(R.id.lvForSBD)
            listview.adapter = adapter

            myHelperSBD = MainActivity.MyDBHelperSaleBreakDown(this, "SaleBreakDownDB", null, 1)
            sqlDBSBD = myHelperSBD.readableDatabase

            val c1:Cursor = sqlDBSBD.rawQuery("select * from SaleBreakDownTBL", null)
            while(c1.moveToNext()){
                adapter.addItem(c1.getString(1),c1.getString(0),c1.getString(2))
            }
            c1.close()
        }


        lvForSBD.onItemClickListener = AdapterView.OnItemClickListener { _, view, position, id ->

            val intent = Intent(this, SaleBreakDownDetail::class.java)
            intent.putExtra("orderNumber", view.orderNumber.text.toString())
            startActivity(intent)
        }

    }
}
