package com.example.icia24hours

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class ListViewAdapter2: BaseAdapter() {

    private var listViewItemList:ArrayList<ListViewItemGoodsList> = ArrayList()

    override fun getCount(): Int {
        return listViewItemList.size
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val pos:Int = position
        val context: Context = parent!!.getContext()
        var convertView:View? = convertView

        if(convertView == null){
            val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.listviewitemgoodslist, parent, false)
        }

        var goodsNameTextView: TextView = convertView!!.findViewById(R.id.goodsNameTV) as TextView
        var barCodeTextView: TextView = convertView.findViewById(R.id.barCodeTV) as TextView
        var salePriceTextView: TextView = convertView.findViewById(R.id.salePriceTV) as TextView
        var stockTextView: TextView = convertView.findViewById(R.id.stockTV) as TextView

        var listViewItem:ListViewItemGoodsList = listViewItemList.get(position)

        goodsNameTextView.setText(listViewItem.getGoodsName())
        barCodeTextView.setText(listViewItem.getBarCode())
        salePriceTextView.setText(listViewItem.getSalePrice())
        stockTextView.setText(listViewItem.getStock())


        return convertView
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return listViewItemList.get(position)
    }

    fun addItem(goodsName:String, barCode:String,salePrice:String,stock:String){
        var item:ListViewItemGoodsList = ListViewItemGoodsList()

        item.setGoodsName(goodsName)
        item.setBarCode(barCode)
        item.setSalePrice(salePrice)
        item.setStock(stock)

        listViewItemList.add(item)
    }

}